package com.ftouchcustomer.Appointment.AppointmentList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ftouchcustomer.Appointment.GetAppointment.ClsGetAppointmentResponseList;
import com.ftouchcustomer.R;

import java.util.ArrayList;
import java.util.List;

public class AdapterGetAppointment extends RecyclerView.Adapter<AdapterGetAppointment.ViewHolder> {

    private List<ClsGetAppointmentResponseList> list = new ArrayList<>();
    private Context context;

    public AdapterGetAppointment(Context mContext) {
        this.context = mContext;
    }

    public void addList(List<ClsGetAppointmentResponseList> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    public interface ItemClickListener {
        void OnClick(ClsGetAppointmentResponseList listResponse, int position, String mode);
    }

    private ItemClickListener itemClickListener;

    public void SetOnItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemView = inflater.inflate(R.layout.row_appointment, parent, false);
        return new ViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ClsGetAppointmentResponseList current = list.get(position);

        holder.tvmName.setText(current.getMerchantName());
        holder.tv_name.setText(current.getCustomerName());
        holder.tv_mobile.setText(current.getAppointmentMobileNo());
        holder.tv_appointmentDate.setText(current.getAppointmentDate());
        holder.tv_Services.setText(current.getServices());
        holder.tv_status.setText(current.getStatus());

        if (current.getStatus().equalsIgnoreCase("Cancelled")) {
            holder.ivDelete.setVisibility(View.GONE);
            holder.tv_status.setTextColor(Color.parseColor("#F44336"));
        } else if (current.getStatus().equalsIgnoreCase("Verified")) {
            holder.tv_status.setTextColor(Color.parseColor("#388E3C"));
        } else if (current.getStatus().equalsIgnoreCase("confirmation pending")) {
            holder.tv_status.setTextColor(Color.parseColor("#FFC107"));
        } else if (current.getStatus().equalsIgnoreCase("Confirm")) {
            holder.tv_status.setTextColor(Color.parseColor("#F57F17"));
            holder.tv_appointment_no.setText(current.getAppointmentNo());
            holder.ll_appointment_no.setVisibility(View.VISIBLE);
            holder.view_appointment_no.setVisibility(View.VISIBLE);
        }

        holder.BindClick(current, itemClickListener, position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvmName;
        TextView tv_name;
        TextView tv_mobile;
        TextView tv_appointmentDate;
        TextView tv_status;
        TextView tv_Services;
        TextView tv_appointment_no;
        LinearLayout ll_appointment_no;
        ImageView ivDelete;
        ImageView ivEdit;
        View view_appointment_no;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvmName = itemView.findViewById(R.id.mName);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_mobile = itemView.findViewById(R.id.tv_mobile);
            tv_appointmentDate = itemView.findViewById(R.id.tv_appointmentDate);
            tv_status = itemView.findViewById(R.id.tv_status);
            tv_Services = itemView.findViewById(R.id.tv_Services);
            ivDelete = itemView.findViewById(R.id.iv_delete);
            ivEdit = itemView.findViewById(R.id.iv_edit);
            tv_appointment_no = itemView.findViewById(R.id.tv_appointment_no);
            ll_appointment_no = itemView.findViewById(R.id.ll_appointment_no);
            view_appointment_no = itemView.findViewById(R.id.view_appointment_no);
        }

        void BindClick(ClsGetAppointmentResponseList listResponse,
                       ItemClickListener itemClickListener, int position) {

            ivDelete.setOnClickListener(v -> itemClickListener.OnClick(listResponse, position, "Cancel"));
            ivEdit.setOnClickListener(v -> itemClickListener.OnClick(listResponse, position, "Tracking"));
        }
    }
}
