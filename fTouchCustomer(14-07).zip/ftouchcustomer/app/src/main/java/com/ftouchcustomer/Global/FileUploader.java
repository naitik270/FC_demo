package com.ftouchcustomer.Global;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import com.ftouchcustomer.PlaceOrder.ClsPlaceOrderResponse;
import com.ftouchcustomer.PlaceOrder.InterfacePlaceOrder;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okio.BufferedSink;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FileUploader {

    private FileUploaderCallback mFileUploaderCallback;
    long filesize = 0l;
    String mode = "";
    private boolean showProgressBar = false;
    Context mContext;
    ClsUserInfo getUserInfo = new ClsUserInfo();


    public FileUploader(Context context) {
        this.mContext = context;
        getUserInfo = ClsGlobal.getUserInfo(mContext);
    }


    public void showUploadProgressBar(boolean showProgressBar) {
        this.showProgressBar = showProgressBar;
    }


    public void placeOrder(File file, int _merchantID, String _merchantCode,
                           String _deliveryType, int _items, int _addressID, String _comment,
                           String _paymentMethod, String _paymentDate, String _paymentStatus, String _paymentReferenceNo) {

        InterfacePlaceOrder interfacePlaceOrder = ApiClient.getRetrofitInstance()
                .create(InterfacePlaceOrder.class);

        PRRequestBody mFile = new PRRequestBody(file);

        MultipartBody.Part fileToUpload = MultipartBody.Part.createFormData(
                "File", file.getName(), mFile);

        RequestBody CustomerID = RequestBody.create(
                MultipartBody.FORM, String.valueOf(getUserInfo.getCustomerId()));

        RequestBody MobileNo = RequestBody.create(
                MultipartBody.FORM, getUserInfo.getRegisteredmobilenumber());

        RequestBody MerchantID = RequestBody.create(
                MultipartBody.FORM, String.valueOf(_merchantID));

        RequestBody MerchantCode = RequestBody.create(
                MultipartBody.FORM, _merchantCode);

        RequestBody DeliveryType = RequestBody.create(
                MultipartBody.FORM, _deliveryType);

        RequestBody Items = RequestBody.create(
                MultipartBody.FORM, String.valueOf(_items));

        RequestBody AddressID = RequestBody.create(
                MultipartBody.FORM, String.valueOf(_addressID));

        RequestBody Comment = RequestBody.create(
                MultipartBody.FORM, _comment);

        RequestBody PaymentMethod = RequestBody.create(
                MultipartBody.FORM, _paymentMethod);

        RequestBody PaymentDate = RequestBody.create(
                MultipartBody.FORM, _paymentDate);

        RequestBody PaymentStatus = RequestBody.create(
                MultipartBody.FORM, _paymentStatus);

        RequestBody PaymentReferenceNo = RequestBody.create(
                MultipartBody.FORM, _paymentReferenceNo);

        Call<ClsPlaceOrderResponse> callPlaceOrder =
                interfacePlaceOrder.placeOrderAPI(fileToUpload,
                        CustomerID, MobileNo, MerchantID,
                        MerchantCode, DeliveryType, Items, AddressID, Comment,
                        PaymentMethod, PaymentDate, PaymentStatus, PaymentReferenceNo);


        Log.e("--Gson--", "callPlaceOrder: " + callPlaceOrder.request().url());

        Log.e("--Gson--", "MobileNo: " + getUserInfo.getRegisteredmobilenumber());
        Log.e("--Gson--", "_merchantID: " + _merchantID);
        Log.e("--Gson--", "_merchantCode: " + _merchantCode);
        Log.e("--Gson--", "_deliveryType: " + _deliveryType);
        Log.e("--Gson--", "_items: " + _items);
        Log.e("--Gson--", "_addressID: " + _addressID);
        Log.e("--Gson--", "_comment: " + _comment);
        Log.e("--Gson--", "_paymentMethod: " + _paymentMethod);
        Log.e("--Gson--", "_paymentDate: " + _paymentDate);
        Log.e("--Gson--", "_paymentStatus: " + _paymentStatus);
        Log.e("--Gson--", "_paymentReferenceNo: " + _paymentReferenceNo);
//
//        Gson gson2 = new Gson();
//        String jsonInString2 = gson2.toJson(callPlaceOrder);
//        Log.e("--URL--", "callPlaceOrder: " + jsonInString2);
//
        callPlaceOrder.enqueue(new Callback<ClsPlaceOrderResponse>() {
            @Override
            public void onResponse(@NonNull Call<ClsPlaceOrderResponse> call,
                                   @NonNull Response<ClsPlaceOrderResponse> response) {
                if (response.body() != null && response.isSuccessful()) {


                    Log.e("--Gson--", "response: " + response);
                    Log.e("--Gson--", "call: " + call);


                    mFileUploaderCallback.onFinish(response.body().getSuccess());

                }
            }

            @Override
            public void onFailure(@NonNull Call<ClsPlaceOrderResponse> call,
                                  @NonNull Throwable t) {
                mFileUploaderCallback.onError();
                Log.e("--Gson--", "onFailure: " + call);
                Log.e("--Gson--", "t: " + t);
            }
        });

    }


    public void SetCallBack(FileUploaderCallback fileUploaderCallback) {
        this.mFileUploaderCallback = fileUploaderCallback;
    }


    public class PRRequestBody extends RequestBody {
        private File mFile;

        private int DEFAULT_BUFFER_SIZE = 20000048;

        PRRequestBody(final File file) {
            mFile = file;
            if (mFile.length() < 524288000) {
                DEFAULT_BUFFER_SIZE = 399999;
            }
        }

        @Override
        public MediaType contentType() {
            // i want to upload only images
            return MediaType.parse("multipart/form-data");
        }

        @Override
        public long contentLength() throws IOException {
            return mFile.length();
        }

        @Override
        public void writeTo(BufferedSink sink) throws IOException {
            long fileLength = mFile.length();
            byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            FileInputStream in = new FileInputStream(mFile);
            long uploaded = 0;
//            Source source = null;

            try {
                int read;
//                source = Okio.source(mFile);
                Handler handler = new Handler(Looper.getMainLooper());

                while ((read = in.read(buffer)) != -1) {


                    // update progress on UI thread
                    if (mode.equalsIgnoreCase("Manual")
                            || mode.equalsIgnoreCase("Manual and Auto") || showProgressBar) {
                        handler.post(new ProgressUpdater(uploaded, fileLength));
                    }

                    uploaded += read;
                    sink.write(buffer, 0, read);
                }
//                sink.writeAll(source);

            } catch (Exception e) {
                Log.e("Exception", e.getMessage());
            } finally {
                in.close();
            }
        }
    }


    private class ProgressUpdater implements Runnable {
        private long mUploaded;
        private long mTotal;

        ProgressUpdater(long uploaded, long total) {
            mUploaded = uploaded;
            mTotal = total;
        }

        @Override
        public void run() {
            int current_percent = (int) (100 * mUploaded / mTotal);
            int total_percent = (int) (100 * mUploaded / mTotal);

            if (mFileUploaderCallback != null) {

                mFileUploaderCallback.onProgressUpdate(current_percent, total_percent,
                        "File Size: " + ClsGlobal.readableFileSize(mUploaded) +
                                "/" + ClsGlobal.readableFileSize(filesize));
            }
        }
    }

    public interface FileUploaderCallback {

        void onError();

        void onFinish(String responses);

        void onProgressUpdate(int currentpercent, int totalpercent, String msg);
    }


}
