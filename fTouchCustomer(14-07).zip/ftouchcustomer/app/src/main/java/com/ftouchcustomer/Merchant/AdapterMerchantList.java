package com.ftouchcustomer.Merchant;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ftouchcustomer.Global.ClsGlobal;
import com.ftouchcustomer.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import java8.util.stream.Collectors;
import java8.util.stream.StreamSupport;

public class AdapterMerchantList extends RecyclerView.Adapter<AdapterMerchantList.ViewHolder> {

    List<ClsMerchantResponseList> lst = new ArrayList<>();
    private LayoutInflater mInflater;
    private Context mContext;
    View itemView;
    String mode = "";

    private OnClickListenerCall mOnClickListenerCall;
    private OnWtsAppClickListenerCall mOnWtsAppClickListenerCall;
    private OnShopNowClickListenerCall mOnShopNowClickListenerCall;
    private OnTimeClickListenerCall mOnTimeClick;
    private OnCastLayoutClick onCastLayoutClick;
    private OnMainImageClick onMainImageClick;
    private OnGoogleMapClick onGoogleMapClick;

    public AdapterMerchantList(Context mContext, String mode) {
        this.mContext = mContext;
        this.mode = mode;
        mInflater = LayoutInflater.from(mContext);
    }

    public void addList(List<ClsMerchantResponseList> list) {
//        this.lst.addAll(list);

        this.lst = list;
        notifyDataSetChanged();
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        itemView = mInflater.inflate(R.layout.row_merchants_list, parent, false);
        return new ViewHolder(itemView);
    }

    public void setOnMobileClick(OnClickListenerCall mOnClickListenerCall) {
        this.mOnClickListenerCall = mOnClickListenerCall;
    }

    public void setOnWtsAppClick(OnWtsAppClickListenerCall mOnWtsAppClickListenerCall) {
        this.mOnWtsAppClickListenerCall = mOnWtsAppClickListenerCall;
    }

    public void setOnShopNowClick(OnShopNowClickListenerCall mOnShopNowClickListenerCall) {
        this.mOnShopNowClickListenerCall = mOnShopNowClickListenerCall;
    }

    public void setOnTimeClick(OnTimeClickListenerCall mOnTimeClick) {
        this.mOnTimeClick = mOnTimeClick;
    }

    public void setOnMainImageClick(OnMainImageClick onMainImageClick) {
        this.onMainImageClick = onMainImageClick;
    }

    public void setOnCastLayoutClick(OnCastLayoutClick onCastLayoutClick) {
        this.onCastLayoutClick = onCastLayoutClick;
    }

    public void setOnMapClick(OnGoogleMapClick onGoogleMapClick) {
        this.onGoogleMapClick = onGoogleMapClick;
    }

    public interface OnClickListenerCall {
        void OnItemClick(ClsMerchantResponseList clsMerchantResponseList);
    }

    public interface OnWtsAppClickListenerCall {
        void OnItemClick(ClsMerchantResponseList clsMerchantResponseList);
    }

    public interface OnShopNowClickListenerCall {
        void OnItemClick(ClsMerchantResponseList clsMerchantResponseList);
    }

    public interface OnTimeClickListenerCall {
        void OnItemClick(List<ClsTiming> lst, ClsMerchantResponseList clsMerchantResponseList);
    }

    public interface OnMainImageClick {
        void OnItemClick(ClsMerchantResponseList clsMerchantResponseList);
    }

    public interface OnCastLayoutClick {
        void OnItemClick(ClsMerchantResponseList clsMerchantResponseList);
    }

    public interface OnGoogleMapClick {
        void OnMapItemClick(ClsMerchantResponseList clsMerchantResponseList);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ClsMerchantResponseList currentObj = lst.get(position);

        List<ClsTiming> lst = new ArrayList<>();
        lst = currentObj.getTiming();

        if (mode.equalsIgnoreCase("FragmentMerchantList")) {
            holder.iv_img_shop_now.setImageResource(R.drawable.ic_clock);
            holder.txt_shop_now.setText("Book Appointment");
            holder.txt_shop_now.setTextSize(10);
        }

        String[] categoryList = currentObj.getCategories().split(",");
        holder.ll_category.setVisibility(View.VISIBLE);
        holder.cast_layout.removeAllViews();

        if (currentObj.getCategories() != null &&
                !currentObj.getCategories().equalsIgnoreCase("")) {

            for (String name : categoryList) {
                AddTimingEditText(holder.cast_layout, name);
            }

        } else {
            AddTimingEditText(holder.cast_layout, "NO PRODUCT FOUND!");
        }

        holder.txt_merchant_name.setText(currentObj.getBusinessName().toUpperCase());

        Log.d("--val--", "distance: " + currentObj.getDistance());
        holder.txt_distance.setText(currentObj.getDistance() + " km");

        if (currentObj.getTiming().size() != 0) {

            List<ClsTiming> list = new ArrayList<>();

            list = StreamSupport.stream(currentObj.getTiming())
                    .filter(s -> s.getWeekDay().equalsIgnoreCase(ClsGlobal.getCurrentDay()))
                    .collect(Collectors.toList());

            for (ClsTiming obj : list) {
//                String finalTime = obj.getWeekDay().concat(" ").concat(obj.getTime());

                String finalTime = "";
                if (obj.getTime().equalsIgnoreCase("Closed")) {
                    finalTime = "Closed";
                } else {
                    finalTime = "Today ".concat(obj.getTime());
                }
                holder.txt_time.setText(finalTime);
            }

            holder.txt_time.setTextColor(Color.parseColor("#000000"));
        } else {
            holder.txt_time.setText("Store timing ?");
            holder.txt_time.setTextColor(Color.parseColor("#007bff"));
        }

        Uri uri = Uri.parse("android.resource://" + mContext.getPackageName() + "/drawable/ic_no_image.xml");

        if (currentObj.getLogoUrl().contains("Not found")) {
            Picasso.get().load(uri)
                    .placeholder(R.drawable.ic_no_image)
                    .resize(120, 60)
                    .into(holder.iv_display_logo);
        } else {
            Picasso.get().load(currentObj.getLogoUrl()).into(holder.iv_display_logo);
        }

        if (currentObj.getOnlineSellingStatus() != null &&
                currentObj.getOnlineSellingStatus().equalsIgnoreCase("Disable")) {
            holder.iv_hot_red.setVisibility(View.VISIBLE);
            holder.iv_green.setVisibility(View.GONE);
            holder.txt_status.setText("STORE IS OFFLINE.");
        } else {
            holder.iv_green.setVisibility(View.VISIBLE);
            holder.iv_hot_red.setVisibility(View.GONE);
            holder.txt_status.setText("STORE IS ONLINE.");
        }

        holder.Bind(currentObj, mOnClickListenerCall);
        holder.BindWtsApp(currentObj, mOnWtsAppClickListenerCall);
        holder.BindTimeApp(lst, currentObj, mOnTimeClick);
        holder.BindShopNow(currentObj, mOnShopNowClickListenerCall);
        holder.BindLogo(currentObj, onMainImageClick);
        holder.BindCastLayout(currentObj, onCastLayoutClick);
        holder.BindMapOpen(currentObj, onGoogleMapClick);

    }

    @Override
    public int getItemCount() {
        return lst.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_distance;
        TextView txt_merchant_name;
        TextView txt_time;
        TextView txt_status;
        TextView txt_shop_now;
        ImageView iv_display_logo;
        ImageView iv_phone;
        ImageView iv_img_shop_now;
        ImageView iv_hot_red;
        ImageView iv_green;
        ImageView iv_wtsApp;
        LinearLayout cast_layout;
        LinearLayout ll_category;
        LinearLayout ll_location;

        public ViewHolder(View itemView) {
            super(itemView);
            iv_green = itemView.findViewById(R.id.iv_green);
            iv_hot_red = itemView.findViewById(R.id.iv_hot_red);
            txt_distance = itemView.findViewById(R.id.txt_distance);
            iv_display_logo = itemView.findViewById(R.id.iv_display_logo);
            txt_merchant_name = itemView.findViewById(R.id.txt_merchant_name);
            iv_phone = itemView.findViewById(R.id.iv_phone);
            iv_img_shop_now = itemView.findViewById(R.id.iv_img_shop_now);
            cast_layout = itemView.findViewById(R.id.cast_layout);
            iv_wtsApp = itemView.findViewById(R.id.iv_wtsApp);
            ll_category = itemView.findViewById(R.id.ll_category);
            txt_shop_now = itemView.findViewById(R.id.txt_shop_now);
            txt_time = itemView.findViewById(R.id.txt_time);
            ll_location = itemView.findViewById(R.id.ll_location);
            txt_status = itemView.findViewById(R.id.txt_status);
        }

        void Bind(final ClsMerchantResponseList clsMerchantResponseList,
                  OnClickListenerCall onClickListenerCall) {
            iv_phone.setOnClickListener(v ->
                    // send current position via Onclick method.
                    onClickListenerCall.OnItemClick(clsMerchantResponseList));
        }

        void BindShopNow(final ClsMerchantResponseList clsMerchantResponseList,
                         OnShopNowClickListenerCall mOnShopNowClickListenerCall) {
            txt_shop_now.setOnClickListener(v ->
                    // send current position via Onclick method.
                    mOnShopNowClickListenerCall.OnItemClick(clsMerchantResponseList));
        }

        void BindWtsApp(final ClsMerchantResponseList clsMerchantResponseList,
                        OnWtsAppClickListenerCall onWtsAppClickListenerCall) {
            iv_wtsApp.setOnClickListener(v ->
                    // send current position via Onclick method.
                    onWtsAppClickListenerCall.OnItemClick(clsMerchantResponseList));
        }

        void BindTimeApp(List<ClsTiming> lst, ClsMerchantResponseList list,
                         OnTimeClickListenerCall onTimeClickListenerCall) {
            txt_time.setOnClickListener(v ->
                    // send current position via Onclick method.
                    onTimeClickListenerCall.OnItemClick(lst, list));
        }

        void BindLogo(final ClsMerchantResponseList clsMerchantResponseList,
                      OnMainImageClick onMainImageClick) {
            iv_display_logo.setOnClickListener(view -> {
                onMainImageClick.OnItemClick(clsMerchantResponseList);
            });
        }

        void BindCastLayout(final ClsMerchantResponseList clsMerchantResponseList,
                            OnCastLayoutClick onCastLayoutClick) {
            cast_layout.setOnClickListener(view -> {
                onCastLayoutClick.OnItemClick(clsMerchantResponseList);
            });
        }

        void BindMapOpen(ClsMerchantResponseList list,
                         OnGoogleMapClick onGoogleMapClick) {
            ll_location.setOnClickListener(v ->
                    // send current position via Onclick method.
                    onGoogleMapClick.OnMapItemClick(list));
        }
    }

    private void AddTimingEditText(LinearLayout linearLayout, String open) {
        LayoutInflater inflater = (LayoutInflater)
                mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View layout2 = inflater.inflate(R.layout.row_category_name, null);
        TextView txt_categories = layout2.findViewById(R.id.txt_categories);
        txt_categories.setText(open);
        linearLayout.addView(layout2, linearLayout.getChildCount() - 1);
    }
}
