package com.ftouchcustomer.NavigationTabs;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import com.ftouchcustomer.Appointment.GetAppointment.AppointmentViewModel;
import com.ftouchcustomer.Appointment.GetAppointment.ClsGetAppointment;
import com.ftouchcustomer.Appointment.GetAppointment.ClsGetAppointmentResponseList;
import com.ftouchcustomer.Global.ClsGlobal;
import com.ftouchcustomer.Global.ClsUserInfo;
import com.ftouchcustomer.R;
import com.google.gson.Gson;
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import smartdevelop.ir.eram.showcaseviewlib.GuideView;
import smartdevelop.ir.eram.showcaseviewlib.config.DismissType;
import smartdevelop.ir.eram.showcaseviewlib.listener.GuideListener;

import static android.content.Context.MODE_PRIVATE;

public class HomeFragment extends Fragment {

    Toolbar toolbar;
    LinearLayout ll_show;
    ViewPager viewPager;
    DotsIndicator dotsIndicator;
    MyPagerAdapter adapter;
    ClsUserInfo clsUserInfo;

    private AppointmentViewModel appointmentViewModel;
    private List<ClsGetAppointmentResponseList> list = new ArrayList<>();

    public HomeFragment() { }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_home, container, false);

        setHasOptionsMenu(true);

        toolbar = v.findViewById(R.id.toolbar);
        ll_show = v.findViewById(R.id.ll_show);
        viewPager = v.findViewById(R.id.viewPager);
        dotsIndicator = v.findViewById(R.id.dots_indicator);
        clsUserInfo = ClsGlobal.getUserInfo(getActivity());
        appointmentViewModel = new ViewModelProvider(this).get(AppointmentViewModel.class);

        adapter = new MyPagerAdapter(getActivity());

        toolbar.setTitle(getString(R.string.text_home));
        toolbar.setTitleTextColor(Color.parseColor("#FFFFFF"));

        main(v);

        return v;
    }

    private void main(View v) {

        if (isFirstTime()) {
            ShowIntro("Appointment", "Here you shows your booked Appointment", ll_show, 1);
        }

        if (!clsUserInfo.getRegisteredmobilenumber().equalsIgnoreCase("")){
            if (ClsGlobal.isNetworkConnected(getActivity())){
                loadAdapter();
            }else{
                Toast.makeText(getActivity(), "Please check your Internet connection", Toast.LENGTH_SHORT).show();
            }
        }/*else{
            Toast.makeText(getActivity(), "Update profile to manage Appointment.", Toast.LENGTH_SHORT).show();
        }*/
    }

    private void loadAdapter() {

        Date date = Calendar.getInstance().getTime();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_YEAR, +7);
        Date newDate = calendar.getTime();

        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String fromDate = df.format(date);
        String toDate = df.format(newDate);

        ClsGetAppointment clsGetAppointment = new ClsGetAppointment();
        clsGetAppointment.setCurrentIndex(1);
        clsGetAppointment.setCustomerMobileNo(clsUserInfo.getRegisteredmobilenumber());
        clsGetAppointment.setMode("Customer");
//        clsGetAppointment.setMerchantCode("");
//        clsGetAppointment.setStatus("");
//        clsGetAppointment.setFromDate("");
//        clsGetAppointment.setToDate("");

        Log.d("Date---", "fromDate: "+fromDate);
        Log.d("Date---", "toDate: "+toDate);

        Gson gson = new Gson();
        String jsonInString = gson.toJson(clsGetAppointment);
        Log.e("--URL--", "loadAdapter: " + jsonInString);

        appointmentViewModel.getAppointment(clsGetAppointment)
                .observe(getViewLifecycleOwner(), clsGetAppointmentResponse -> {

                    String msg = clsGetAppointmentResponse.getSuccess();

                    if ("0".equals(msg)) {
                        Toast.makeText(getActivity(), "Fail to get Appointment", Toast.LENGTH_SHORT).show();
                    } else if ("1".equals(msg)) {

                        if (viewPager != null) {

                            viewPager.setAdapter(adapter);
                            list = clsGetAppointmentResponse.getData();

                            String jsonInStringxx = gson.toJson(list);
                            Log.e("--URL--", "jsonInStringxx---" + jsonInStringxx);

                            if (list.size() != 0) {
                                adapter.addList(list);
                            }
                        }
                        dotsIndicator.setViewPager(viewPager);
                    } else if ("2".equals(msg)) {
                        Toast.makeText(getActivity(), "Mode is Required.", Toast.LENGTH_SHORT).show();
                    } else if ("3".equals(msg)) {
                        Toast.makeText(getActivity(), "Merchant Code is Required.", Toast.LENGTH_SHORT).show();
                    } else if ("4".equals(msg)) {
                        Toast.makeText(getActivity(), "Customer Mobile No is Required.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), "Something went wrong!", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void ShowIntro(String title, String text, View viewId, final int type) {

        new GuideView.Builder(getActivity())
                .setTitle(title)
                .setContentText(text)
                .setTargetView(viewId)
                .setContentTextSize(12)
                .setTitleTextSize(14)
                .setDismissType(DismissType.targetView)
                .setGuideListener(new GuideListener() {
                    @Override
                    public void onDismiss(View view) {
                        if (type == 1) {
//                            ShowIntro("Appointment", "Here you shows your booked Appointment", ll_show, 6);
                        }
                    }
                })
                .build()
                .show();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Home");
    }

    private boolean isFirstTime() {
        SharedPreferences preferences = getActivity().getPreferences(MODE_PRIVATE);
        boolean ranBefore = preferences.getBoolean("HomeFragment", false);
        if (!ranBefore) {
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("HomeFragment", true);
            editor.apply();
        }
        return !ranBefore;
    }
}
