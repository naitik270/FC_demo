package com.ftouchcustomer.DisplayImage;

public class ClsDisplayImage {


    public String get_imgPath() {
        return _imgPath;
    }

    public void set_imgPath(String _imgPath) {
        this._imgPath = _imgPath;
    }

    String _imgPath = "";
}
