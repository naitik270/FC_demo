package com.ftouchcustomer.Interface;

import com.ftouchcustomer.Database.Entity.ClsOrderDetailsEntity;
import com.ftouchcustomer.Orders.ClsCustomerOrderDetail;
import com.ftouchcustomer.Orders.ClsCustomerOrderListParams;
import com.ftouchcustomer.Orders.ClsCustomerOrderResponse;
import com.ftouchcustomer.Orders.ClsGetMerchantPaymentMethodResponse;
import com.ftouchcustomer.Orders.ClsPlaceOrderDeleteResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface InterfaceGetOrderList {

    @POST("CustomerV1/GetCustomerOrderList")
    Call<ClsCustomerOrderResponse> getCustomerOrderListAPI(@Body ClsCustomerOrderListParams obj);


    @GET("CustomerV1/CustomerOrderDetails")
    Call<ClsCustomerOrderDetail> getOnlineOrdersDetails(@Query("Orderid") int OrderId,
                                                        @Query("Customerid") int Customerid,
                                                        @Query("CustomerMobileNo") String CustomerMobileNo);


    @GET("CustomerV1/CustomerOrderCancelled")
    Call<ClsPlaceOrderDeleteResponse> deletePlaceOrder(@Query("OrderID") int OrderID,
                                                       @Query("MobileNo") String MobileNo,
                                                       @Query("MerchantCode") String MerchantCode,
                                                       @Query("CancelledBy") String CancelledBy,
                                                       @Query("Mode") String Mode,
                                                       @Query("Reason") String Reason);

    @GET("CustomerV1/GetMerchantPaymentMethod")
    Call<ClsGetMerchantPaymentMethodResponse> getMerchantPaymentMethod(@Query("MerchantCode") String MerchantCode);

    @GET
    Call<List<ClsOrderDetailsEntity>> getOnlineOrderItems(@Url String url);


}
