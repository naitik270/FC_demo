package com.ftouchcustomer.Orders;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ftouchcustomer.Database.Entity.ClsOrderDetailsEntity;
import com.ftouchcustomer.Global.ApiClient;
import com.ftouchcustomer.Global.ClsGlobal;
import com.ftouchcustomer.Interface.InterfaceGetOrderList;
import com.ftouchcustomer.R;
import com.google.gson.Gson;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityCustomerOrderDetails extends AppCompatActivity {


    TextView txt_order_status, txt_delivery_type, txt_items_count, txt_order_date, txt_status_remark,
            txt_delivery_datetime, txt_address, txt_comment;
    LinearLayout progress_bar_layout, main_layout, noInternet_connection;

    int CustomerID = 0;
    String MobileNo = "";
    String MerchantCode = "";
    String CanceledBy = "";
    int OrderId = 0;
    TextView txt_name;
    TextView txt_invoice;
    TextView txt_cancel_order;
    OnlineOrderItemAdapter adapter;
    RecyclerView rv;
    TextView txt_payment_method, txt_payment_ref_no, txt_payment_date, txt_payment_status;
    ImageView iv_invoice;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_display);

        main();
    }

    private void main() {

        CustomerID = getIntent().getIntExtra("MerchantID", 0);
        OrderId = getIntent().getIntExtra("OrderId", 0);
        MobileNo = getIntent().getStringExtra("MobileNo");
        MerchantCode = getIntent().getStringExtra("MerchantCode");
        CanceledBy = getIntent().getStringExtra("CanceledBy");

        Toolbar toolbar = findViewById(R.id.toolbar);

        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setTitle("");
        toolbar.setSubtitle("");

        Log.d("--va--", "MobileNo: " + MobileNo);
        Log.d("--va--", "OrderId: " + OrderId);
        Log.d("--va--", "MerchantID: " + CustomerID);
        Log.d("--va--", "CanceledBy: " + CanceledBy);

        rv = findViewById(R.id.rv);
        rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        adapter = new OnlineOrderItemAdapter();
        rv.setAdapter(adapter);
        txt_invoice = findViewById(R.id.txt_invoice);
        txt_cancel_order = findViewById(R.id.txt_cancel_order);
        txt_order_status = findViewById(R.id.txt_order_status);
        txt_delivery_type = findViewById(R.id.txt_delivery_type);
        txt_items_count = findViewById(R.id.txt_items_count);
        txt_order_date = findViewById(R.id.txt_order_date);
        txt_status_remark = findViewById(R.id.txt_status_remark);
        txt_delivery_datetime = findViewById(R.id.txt_delivery_datetime);
        txt_address = findViewById(R.id.txt_address);
        txt_comment = findViewById(R.id.txt_comment);
        txt_name = findViewById(R.id.txt_name);
        txt_payment_method = findViewById(R.id.txt_payment_method);
        txt_payment_ref_no = findViewById(R.id.txt_payment_ref_no);
        txt_payment_date = findViewById(R.id.txt_payment_date);
        txt_payment_status = findViewById(R.id.txt_payment_status);
        iv_invoice = findViewById(R.id.iv_invoice);

        // LinearLayout.
        progress_bar_layout = findViewById(R.id.progress_bar_layout);
        main_layout = findViewById(R.id.main_layout);
        noInternet_connection = findViewById(R.id.noInternet_connection);

        if (ClsGlobal.isNetworkConnected(getApplicationContext())) {
            noInternet_connection.setVisibility(View.GONE);
            main_layout.setVisibility(View.VISIBLE);
            getOrderDetailsFromApi();
        } else {
            main_layout.setVisibility(View.GONE);
            noInternet_connection.setVisibility(View.VISIBLE);
        }

        txt_cancel_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelPlaceOrder();
            }
        });

        txt_invoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (invoiceURL != null && !invoiceURL.equalsIgnoreCase("")) {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(invoiceURL));
                    startActivity(i);
                } else {
                    Toast.makeText(ActivityCustomerOrderDetails.this, "No url found.", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    String invoiceURL = "";


    private void cancelPlaceOrder() {
        main_layout.setVisibility(View.GONE);
        progress_bar_layout.setVisibility(View.VISIBLE);


        InterfaceGetOrderList mainInterface = ApiClient.getRetrofitInstance()
                .create(InterfaceGetOrderList.class);

//        Call<ClsOrderDetail> call = mainInterface.getOnlineOrdersDetails("1",
//                "2066","CHO001");

        Call<ClsPlaceOrderDeleteResponse> call = mainInterface.deletePlaceOrder(OrderId, MobileNo,
                MerchantCode, CanceledBy, "Customer", "CANCEL ORDER");

        Log.e("--va--", "Url: " + call.request().url());


        call.enqueue(new Callback<ClsPlaceOrderDeleteResponse>() {

            @Override
            public void onResponse(@NonNull Call<ClsPlaceOrderDeleteResponse> call,
                                   @NonNull Response<ClsPlaceOrderDeleteResponse> response) {
                main_layout.setVisibility(View.VISIBLE);
                progress_bar_layout.setVisibility(View.GONE);

                if (response.body() != null && response.isSuccessful()) {

                    Log.e("--va--", "IFIF: " + response.code());

                } else {

                    Log.e("--va--", "ELSE: " + response.code());

                }


            }

            @Override
            public void onFailure(@NonNull Call<ClsPlaceOrderDeleteResponse> call, @NonNull Throwable t) {
                main_layout.setVisibility(View.VISIBLE);
                progress_bar_layout.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "Something went wrong,please try again"
                        , Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void getOrderItems(String OrderItemsUrl) {
        InterfaceGetOrderList mainInterface = ApiClient.getRetrofitInstance()
                .create(InterfaceGetOrderList.class);

        Call<List<ClsOrderDetailsEntity>> call = mainInterface.getOnlineOrderItems(OrderItemsUrl);
        Log.e("--va--", "getOrderItems: " + call.request().url());

        call.enqueue(new Callback<List<ClsOrderDetailsEntity>>() {
            @Override
            public void onResponse(@NonNull Call<List<ClsOrderDetailsEntity>> call,
                                   @NonNull Response<List<ClsOrderDetailsEntity>> response) {

                if (response.body() != null && response.isSuccessful()) {
                    Gson gson2 = new Gson();
                    String jsonInString2 = gson2.toJson(response.body());
                    Log.e("Check", "response:--- " + jsonInString2);

                    if (response.body().size() > 0) {
                        adapter.AddItems(response.body());
                    }

                }


            }

            @Override
            public void onFailure(@NonNull Call<List<ClsOrderDetailsEntity>> call,
                                  @NonNull Throwable t) {
                Toast.makeText(getApplicationContext(), "Something went wrong,please try again",
                        Toast.LENGTH_SHORT).show();
            }
        });

    }


    private void getOrderDetailsFromApi() {
        main_layout.setVisibility(View.GONE);
        progress_bar_layout.setVisibility(View.VISIBLE);

        InterfaceGetOrderList mainInterface = ApiClient.getRetrofitInstance()
                .create(InterfaceGetOrderList.class);

//        Call<ClsOrderDetail> call = mainInterface.getOnlineOrdersDetails("1",
//                "2066","CHO001");

        Call<ClsCustomerOrderDetail> call = mainInterface.getOnlineOrdersDetails(OrderId,
                CustomerID, MobileNo);

        Log.e("--va--", "Url: " + call.request().url());

        call.enqueue(new Callback<ClsCustomerOrderDetail>() {

            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(@NonNull Call<ClsCustomerOrderDetail> call,
                                   @NonNull Response<ClsCustomerOrderDetail> response) {
                main_layout.setVisibility(View.VISIBLE);
                progress_bar_layout.setVisibility(View.GONE);

//                Gson gson1 = new Gson();
//                String jsonInString3 = gson1.toJson(response.body());
//                Log.e("Check", "Final:--- " + jsonInString3);
//                Log.e("Check", "Final:--- " + response.code());


                if (response.body() != null && response.isSuccessful()) {
                    ClsCustomerOrderDetail.ClsDataOrderDetails clsOrderDetail = response.body().getData();

//                    txt_tool_bar_order_no.setText(clsOrderDetail.getOrderNO());

                    txt_order_status.setText(clsOrderDetail.getOrderStatus().toUpperCase());
                    txt_delivery_type.setText("Delivery Type: " + clsOrderDetail.getDeliveryType());
                    txt_items_count.setText("[ " + String.valueOf(clsOrderDetail.getItemscount()).concat(" ]"));
                    txt_order_date.setText("Date: " + clsOrderDetail.getOrderDate());

                    txt_status_remark.setText("Status Remark: " + clsOrderDetail.getStatusRemark());
                    txt_delivery_datetime.setText("Delivery Datetime: " + clsOrderDetail.getDeliveryDatetime());

                    txt_address.setText("Address: " + clsOrderDetail.getAddress());
                    txt_comment.setText("Comment: " + clsOrderDetail.getComment());
                    txt_name.setText(clsOrderDetail.getMerchantName().toUpperCase());
                    txt_payment_method.setText("Payment Method: " + clsOrderDetail.getPaymentMethod().toUpperCase());
                    txt_payment_ref_no.setText("Payment Ref: " + clsOrderDetail.getPaymentReferenceNo());
                    txt_payment_date.setText("Payment Date: " + clsOrderDetail.getPaymentDate());
                    txt_payment_status.setText("Payment Status: " + clsOrderDetail.getPaymentStatus().toUpperCase());
                    if (clsOrderDetail.getInvoiceURL() != null) {
                        iv_invoice.setVisibility(View.VISIBLE);
                        invoiceURL = clsOrderDetail.getInvoiceURL();
                    } else {
                        iv_invoice.setVisibility(View.GONE);
                        invoiceURL = "";
                    }
                    getOrderItems(clsOrderDetail.getItemsFileUrl());
                }


            }

            @Override
            public void onFailure(@NonNull Call<ClsCustomerOrderDetail> call, @NonNull Throwable t) {
                main_layout.setVisibility(View.VISIBLE);
                progress_bar_layout.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "Something went wrong,please try again"
                        , Toast.LENGTH_SHORT).show();
            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


}
