package com.ftouchcustomer.Orders;

import androidx.annotation.Nullable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ClsCustomerOrderDetail {

    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("data")
    @Expose
    private ClsDataOrderDetails data;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ClsDataOrderDetails getData() {
        return data;
    }

    public void setData(ClsDataOrderDetails data) {
        this.data = data;
    }

    public class ClsDataOrderDetails {


        @SerializedName("OrderNO")
        @Expose
        private String orderNO;
        @SerializedName("OrderID")
        @Expose
        private Integer orderID;
        @SerializedName("CustomerID")
        @Expose
        private Integer customerID;
        @SerializedName("MerchantID")
        @Expose
        private Integer merchantID;
        @SerializedName("MerchantCode")
        @Expose
        private String merchantCode;
        @SerializedName("MerchantName")
        @Expose
        private String merchantName;
        @SerializedName("DeliveryType")
        @Expose
        private String deliveryType;
        @SerializedName("Itemscount")
        @Expose
        private Integer itemscount;
        @SerializedName("PaymentMethod")
        @Expose
        private String paymentMethod;
        @SerializedName("PaymentDate")
        @Expose
        private String paymentDate;
        @SerializedName("PaymentStatus")
        @Expose
        private String paymentStatus;
        @SerializedName("PaymentReferenceNo")
        @Expose
        private String paymentReferenceNo;
        @SerializedName("ItemsFileUrl")
        @Expose
        private String itemsFileUrl;
        @SerializedName("OrderDate")
        @Expose
        private String orderDate;
        @SerializedName("OrderStatus")
        @Expose
        private String orderStatus;
        @SerializedName("StatusDate")
        @Expose
        private String statusDate;
        @SerializedName("StatusRemark")
        @Expose
        private String statusRemark;
        @SerializedName("DeliveryDatetime")
        @Expose
        private String deliveryDatetime;
        @SerializedName("CancelledBy")
        @Expose
        private String cancelledBy;
        @SerializedName("Address")
        @Expose
        private String address;
        @SerializedName("InvoiceURL")
        @Expose
        private String invoiceURL;
        @SerializedName("Comment")
        @Expose
        private String comment;

        public String getOrderNO() {
            return orderNO;
        }

        public void setOrderNO(String orderNO) {
            this.orderNO = orderNO;
        }

        public Integer getOrderID() {
            return orderID;
        }

        public void setOrderID(Integer orderID) {
            this.orderID = orderID;
        }

        public Integer getCustomerID() {
            return customerID;
        }

        public void setCustomerID(Integer customerID) {
            this.customerID = customerID;
        }

        public Integer getMerchantID() {
            return merchantID;
        }

        public void setMerchantID(Integer merchantID) {
            this.merchantID = merchantID;
        }

        public String getMerchantCode() {
            return merchantCode;
        }

        public void setMerchantCode(String merchantCode) {
            this.merchantCode = merchantCode;
        }

        public String getMerchantName() {
            return merchantName;
        }

        public void setMerchantName(String merchantName) {
            this.merchantName = merchantName;
        }

        public String getDeliveryType() {
            return deliveryType;
        }

        public void setDeliveryType(String deliveryType) {
            this.deliveryType = deliveryType;
        }

        public Integer getItemscount() {
            return itemscount;
        }

        public void setItemscount(Integer itemscount) {
            this.itemscount = itemscount;
        }

        public String getPaymentMethod() {
            return paymentMethod;
        }

        public void setPaymentMethod(String paymentMethod) {
            this.paymentMethod = paymentMethod;
        }

        public String getPaymentDate() {
            return paymentDate;
        }

        public void setPaymentDate(String paymentDate) {
            this.paymentDate = paymentDate;
        }

        public String getPaymentStatus() {
            return paymentStatus;
        }

        public void setPaymentStatus(String paymentStatus) {
            this.paymentStatus = paymentStatus;
        }

        public String getPaymentReferenceNo() {
            return paymentReferenceNo;
        }

        public void setPaymentReferenceNo(String paymentReferenceNo) {
            this.paymentReferenceNo = paymentReferenceNo;
        }

        public String getItemsFileUrl() {
            return itemsFileUrl;
        }

        public void setItemsFileUrl(String itemsFileUrl) {
            this.itemsFileUrl = itemsFileUrl;
        }

        public String getOrderDate() {
            return orderDate;
        }

        public void setOrderDate(String orderDate) {
            this.orderDate = orderDate;
        }

        public String getOrderStatus() {
            return orderStatus;
        }

        public void setOrderStatus(String orderStatus) {
            this.orderStatus = orderStatus;
        }

        public String getStatusDate() {
            return statusDate;
        }

        public void setStatusDate(String statusDate) {
            this.statusDate = statusDate;
        }

        public String getStatusRemark() {
            return statusRemark;
        }

        public void setStatusRemark(String statusRemark) {
            this.statusRemark = statusRemark;
        }

        public String getDeliveryDatetime() {
            return deliveryDatetime;
        }

        public void setDeliveryDatetime(String deliveryDatetime) {
            this.deliveryDatetime = deliveryDatetime;
        }

        public String getCancelledBy() {
            return cancelledBy;
        }

        public void setCancelledBy(String cancelledBy) {
            this.cancelledBy = cancelledBy;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getInvoiceURL() {
            return invoiceURL;
        }

        public void setInvoiceURL(String invoiceURL) {
            this.invoiceURL = invoiceURL;
        }

        public String getComment() {
            return comment;
        }

        public void setComment(String comment) {
            this.comment = comment;
        }

    }
}
