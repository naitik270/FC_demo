package com.ftouchcustomer.Interface;


import com.ftouchcustomer.Classes.ClsSettingNameVal;

public interface OnClickListenerSetting {
    void OnItemClick(ClsSettingNameVal clsSettingNameVal);
}
