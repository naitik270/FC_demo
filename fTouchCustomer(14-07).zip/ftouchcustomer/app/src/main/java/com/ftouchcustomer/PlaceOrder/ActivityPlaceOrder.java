package com.ftouchcustomer.PlaceOrder;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.ftouchcustomer.CustomerAddress.ActivityAddress;
import com.ftouchcustomer.Database.Entity.ClsOrderDetailsEntity;
import com.ftouchcustomer.Global.ClsGlobal;
import com.ftouchcustomer.Global.ClsUserInfo;
import com.ftouchcustomer.Global.FileUploader;

import com.ftouchcustomer.LoginActivity;
import com.ftouchcustomer.Merchant.ActivityMerchantList;
import com.ftouchcustomer.Merchant.ClsMerchantResponseList;
import com.ftouchcustomer.NavigationTabs.BottomNavigationActivity;
import com.ftouchcustomer.Orders.ClsGetMerchantPaymentMethodList;
import com.ftouchcustomer.Orders.ClsGetMerchantPaymentMethodResponse;
import com.ftouchcustomer.R;
import com.ftouchcustomer.SplashActivity;
import com.ftouchcustomer.ViewModelClass.AddToItemViewModel;
import com.google.gson.Gson;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static com.ftouchcustomer.Global.ClsGlobal.ItemsJsonFile;
import static com.ftouchcustomer.Global.ClsGlobal.ItemsTemp_Folder;
import static com.ftouchcustomer.Global.ConnectionCheckBroadcast.CheckInternetConnection;

public class ActivityPlaceOrder extends AppCompatActivity {

    private static final int REQUEST_CODE_ASK_PERMISSIONS = 123;
    ImageView iv_get_address;
    TextView txt_delivery_charges;
    TextView txt_delivery_description;
    TextView txt_address;
    TextView txt_name;
    TextView txt_change;
    TextView txt_mobile;
    TextView txt_place_order;
    List<ClsOrderDetailsEntity> lst = new ArrayList<>();
    int _orderDetailID = 0;
    int _customerID = 0;
    String _customerCode = "";
    EditText edt_comment;
    AddToItemViewModel addToItemViewModel;
    public static final int REQUEST_CODE = 102;
    String address = "";
    String type = "";
    String name = "";
    String mobile = "";
    int addressID = 0;
    TextView txt_payment_mode;
    List<ClsGetMerchantPaymentMethodList> lstClsGetMerchantPaymentMethodLists = new ArrayList<>();
    ClsUserInfo clsUserInfo;
    LinearLayout ll_address;
    LinearLayout ll_select_address;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_order);
        addToItemViewModel = new
                ViewModelProvider(this).get(AddToItemViewModel.class);

        main();
    }

    @SuppressLint({"ShowToast", "SetTextI18n"})
    private void main() {

        clsUserInfo = ClsGlobal.getUserInfo(this);
        _orderDetailID = getIntent().getIntExtra("_orderDetailID", 0);
        _customerID = getIntent().getIntExtra("_customerID", 0);
        _customerCode = getIntent().getStringExtra("_customerCode");
        lst = (List<ClsOrderDetailsEntity>) getIntent().getSerializableExtra("List");

        ll_select_address = findViewById(R.id.ll_select_address);
        txt_delivery_charges = findViewById(R.id.txt_delivery_charges);
        txt_name = findViewById(R.id.txt_name);
        ll_address = findViewById(R.id.ll_address);
        txt_mobile = findViewById(R.id.txt_mobile);
        txt_change = findViewById(R.id.txt_change);
        txt_delivery_description = findViewById(R.id.txt_delivery_description);

        edt_comment = findViewById(R.id.edt_comment);
        txt_place_order = findViewById(R.id.txt_place_order);

        txt_payment_mode = findViewById(R.id.txt_payment_mode);
        SpannableString cString = new SpannableString(getString(R.string.other));
        cString.setSpan(new UnderlineSpan(), 0, cString.length(), 0);
        txt_payment_mode.setText(cString);

        txt_address = findViewById(R.id.txt_address);
        txt_address.setHint("SELECT DELIVERY ADDRESS");
        iv_get_address = findViewById(R.id.iv_get_address);

        iv_get_address.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ActivityAddress.class);
            intent.putExtra("placeOrder", "placeOrder");
            startActivityForResult(intent, REQUEST_CODE);
        });

        txt_change.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ActivityAddress.class);
            intent.putExtra("placeOrder", "placeOrder");
            startActivityForResult(intent, REQUEST_CODE);
        });

        txt_place_order.setOnClickListener(v -> {

            requestPermission();

/*
            if (Validation()) {
                if (clsUserInfo.getRegisteredmobilenumber() != null &&
                        !clsUserInfo.getRegisteredmobilenumber().isEmpty()) {
                    showAlertDialog("NoSkip");
                } else {
                    showAlertDialog("skip");
                }
            }
*/

        });

        getMerchantPaymentMethod();

        txt_payment_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayPaymentMethod(lstClsGetMerchantPaymentMethodLists);
            }
        });

    }

    private Boolean Validation() {

        if (txt_address.getText() == null || txt_address.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Address is required", Toast.LENGTH_SHORT).show();
            txt_address.requestFocus();
            return false;
        }

        if (!CheckInternetConnection(getApplicationContext())) {
            Toast.makeText(getApplicationContext(), "You are not connected to Internet", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    @SuppressLint("SetTextI18n")
    void displayPaymentMethod(List<ClsGetMerchantPaymentMethodList> lst) {

        Dialog dialog = new Dialog(Objects.requireNonNull(ActivityPlaceOrder.this));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_listview);
        dialog.setCancelable(true);
        TextView txt_title = dialog.findViewById(R.id.txt_title);
        txt_title.setText("Payment Method");

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(Objects.requireNonNull(dialog.getWindow()).getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setAttributes(lp);

        ListView lv_lst = dialog.findViewById(R.id.lv_lst);

        AdapterPaymentMethod adapterTimeList =
                new AdapterPaymentMethod(ActivityPlaceOrder.this, lst);

        lv_lst.setAdapter(adapterTimeList);

        dialog.show();
    }

    void getMerchantPaymentMethod() {

        addToItemViewModel.getMerchantPaymentMethod("CHA001").observe(this, new Observer<ClsGetMerchantPaymentMethodResponse>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onChanged(ClsGetMerchantPaymentMethodResponse clsGetMerchantPaymentMethodResponse) {

                lstClsGetMerchantPaymentMethodLists = clsGetMerchantPaymentMethodResponse.getData();
                Log.d("--List--", "size: " + lstClsGetMerchantPaymentMethodLists.size());

                txt_delivery_charges.setText("Delivery Charges: \u20B9 " +
                        clsGetMerchantPaymentMethodResponse.getDeliveryCharges());

                if (clsGetMerchantPaymentMethodResponse.getDeliveryChargesDescription() != null &&
                        !clsGetMerchantPaymentMethodResponse.getDeliveryChargesDescription().equalsIgnoreCase("")) {
                    txt_delivery_description.setText("Description: " +
                            clsGetMerchantPaymentMethodResponse.getDeliveryChargesDescription());
                } else {
                    txt_delivery_description.setText("Description: No Delivery Charges");
                }

                Gson gson = new Gson();
                String jsonInString = gson.toJson(lstClsGetMerchantPaymentMethodLists);
                Log.e("--URL--", "Gson: " + jsonInString);

            }
        });
    }

    private ProgressDialog pd;

    @SuppressLint("StaticFieldLeak")
    void callPlaceOrderAPI() {

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                pd = ClsGlobal._prProgressDialog(ActivityPlaceOrder.this, "please wait your order is in process.", false, 3000);
                pd.show();
            }

            @Override
            protected Void doInBackground(Void... voids) {

                if (lst != null && lst.size() != 0) {

                    Gson gson = new Gson();
                    String itemsJsonString = gson.toJson(lst);
                    Log.e("--Gson--", "value: " + itemsJsonString);

                    ClsGlobal.generateFileFromString(ActivityPlaceOrder.this, new File(ItemsJsonFile).getName(),
                            ".fTouchTemp", itemsJsonString);
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void insertResult) {
                super.onPostExecute(insertResult);

                FileUploader fileUploader = new FileUploader(ActivityPlaceOrder.this);

                File file = new File(ItemsTemp_Folder);

                if (!file.exists()) {
                    file.mkdirs();
                    Log.d("--URL--", "IFIFIF" + file);
                } else {
                    Log.d("--URL--", "ELSE" + file);
                }

                Log.d("--URL--", "getParentFile: "
                        + file.getParentFile());
                fileUploader.placeOrder(new File(ItemsJsonFile), _customerID,
                        _customerCode, type,
                        lst.size(), addressID, edt_comment.getText().toString(),
                        "COD", ClsGlobal.getPlaceOrderDate(), "DONE", "ref0808098");


                fileUploader.showUploadProgressBar(false);

                fileUploader.SetCallBack(new FileUploader.FileUploaderCallback() {

                    @Override
                    public void onError() {
//                        latch.countDown();
                        Log.e("--Gson--", "onError");
                    }

                    @Override
                    public void onFinish(String responses) {

                        addToItemViewModel.DeleteOrderByCode(_customerCode);
                        Log.e("--Gson--", "responses: " + responses);
                        pd.dismiss();

                        Intent i = new Intent(getApplicationContext(), BottomNavigationActivity.class);
                        i.putExtra("placeOrder", "placeOrder");
                        startActivity(i);
                        finish();
                    }

                    @Override
                    public void onProgressUpdate(int currentpercent, int totalpercent, String msg) {
                        Log.e("--Test--", "msg: " + msg);
                    }
                });
            }
        }.execute();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
                if (data != null) {
                    ll_address.setVisibility(View.VISIBLE);
                    ll_select_address.setVisibility(View.GONE);
                    name = data.getStringExtra("name");
                    mobile = data.getStringExtra("mobile");
                    address = data.getStringExtra("address");
                    type = data.getStringExtra("type");
                    addressID = data.getIntExtra("addressID", 0);
                } else {
                    txt_address.setHint("NO ADDRESS SELECTED");
                    ll_address.setVisibility(View.GONE);
                    ll_select_address.setVisibility(View.VISIBLE);
                }
                Log.d("--add--", "address: " + address);
                txt_address.setText(address);
                txt_name.setText(name);
                txt_mobile.setText(mobile);
            }
        } catch (Exception ex) {
            Toast.makeText(ActivityPlaceOrder.this, ex.toString(),
                    Toast.LENGTH_SHORT).show();
        }
    }

    String[] PERMISSIONS;

    private void requestPermission() {

        PERMISSIONS = new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
        };

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            if (Validation()) {
                if (clsUserInfo.getRegisteredmobilenumber() != null &&
                        !clsUserInfo.getRegisteredmobilenumber().isEmpty()) {
                    showAlertDialog("NoSkip");
                } else {
                    showAlertDialog("skip");
                }
            }

//            ActivityCompat.requestPermissions(this, PERMISSIONS, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            if (Validation()) {
                areYouSureDialog();
            }
/*
            if (Validation()) {
                if (clsUserInfo.getRegisteredmobilenumber() != null &&
                        !clsUserInfo.getRegisteredmobilenumber().isEmpty()) {
                    showAlertDialog("NoSkip");
                } else {
                    showAlertDialog("skip");
                }
            }
*/
        }
    }

    private void areYouSureDialog() {

        final Dialog dialog = new Dialog(ActivityPlaceOrder.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dilaog_cust_alert);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(Objects.requireNonNull(dialog.getWindow()).getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        TextView content = dialog.findViewById(R.id.content);
        Button btn_ok = dialog.findViewById(R.id.btn_ok);
        Button btn_no = dialog.findViewById(R.id.btn_no);
        btn_no.setVisibility(View.VISIBLE);

        content.setText(getText(R.string.alert_place_order));

        btn_ok.setOnClickListener(v -> {
            dialog.dismiss();
            callPlaceOrderAPI();

        });

        btn_no.setOnClickListener(v -> {
            dialog.dismiss();
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_CODE_ASK_PERMISSIONS) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
               /* boolean validation = Validation();
                if (validation) {
                    callPlaceOrderAPI();
                }*/
            } else {
                Toast.makeText(this, "Please allow Storage permission.", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    @SuppressLint("SetTextI18n")
    private void showAlertDialog(String mode) {
        final Dialog dialog = new Dialog(ActivityPlaceOrder.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dilaog_cust_alert);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(Objects.requireNonNull(dialog.getWindow()).getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        TextView content = dialog.findViewById(R.id.content);
        Button btn_ok = dialog.findViewById(R.id.btn_ok);


        if (mode != null && mode.equalsIgnoreCase("skip")) {
            content.setText(getText(R.string.alert_skip));
        } else {
            content.setText(getText(R.string.alert_permission));
        }

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                if (mode != null && mode.equalsIgnoreCase("skip")) {
                    Intent i = new Intent(ActivityPlaceOrder.this, LoginActivity.class);
                    i.putExtra("noLogin", "noLogin");
                    startActivity(i);
                    finish();
                } else {
//                    requestPermission();
                    ActivityCompat.requestPermissions(ActivityPlaceOrder.this, PERMISSIONS, REQUEST_CODE_ASK_PERMISSIONS);

                }

            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }


}
