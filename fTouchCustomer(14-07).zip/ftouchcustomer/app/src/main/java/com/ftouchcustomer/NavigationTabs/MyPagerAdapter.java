package com.ftouchcustomer.NavigationTabs;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.ftouchcustomer.Appointment.GetAppointment.ClsGetAppointmentResponseList;
import com.ftouchcustomer.R;

import java.util.ArrayList;
import java.util.List;

class MyPagerAdapter extends PagerAdapter {

    private static final String TAG = "ImageViewPage";
    private LayoutInflater mLayoutInflater;
    private List<ClsGetAppointmentResponseList> mResources = new ArrayList<>();
    private Context context;

    public MyPagerAdapter(Context mContext) {
        this.context = mContext;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void addList(List<ClsGetAppointmentResponseList> list) {
        this.mResources = list;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mResources.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        View itemView = mLayoutInflater.inflate(R.layout.row_dashboard_appointment, container, false);

        TextView tvmName = itemView.findViewById(R.id.mName);
        TextView tv_name = itemView.findViewById(R.id.tv_name);
        TextView tv_mobile = itemView.findViewById(R.id.tv_mobile);
        TextView tv_appointmentDate = itemView.findViewById(R.id.tv_appointmentDate);
        TextView tv_status = itemView.findViewById(R.id.tv_status);
        TextView tv_Services = itemView.findViewById(R.id.tv_Services);
        TextView tv_appointment_no = itemView.findViewById(R.id.tv_appointment_no);
        LinearLayout ll_appointment_no = itemView.findViewById(R.id.ll_appointment_no);
//        View view_appointment_no = itemView.findViewById(R.id.view_appointment_no);

        tvmName.setText(mResources.get(position).getMerchantName());
        tv_name.setText(mResources.get(position).getCustomerName());
        tv_mobile.setText(mResources.get(position).getAppointmentMobileNo());
        tv_appointmentDate.setText(mResources.get(position).getAppointmentDate());
        tv_Services.setText(mResources.get(position).getServices());
        tv_status.setText(mResources.get(position).getStatus());

        tv_appointment_no.setText(mResources.get(position).getAppointmentNo());
        ll_appointment_no.setVisibility(View.VISIBLE);
//        view_appointment_no.setVisibility(View.VISIBLE);

        if (mResources.get(position).getStatus().equalsIgnoreCase("Cancelled")) {
            tv_status.setBackgroundColor(Color.parseColor("#F44336"));
        } else if (mResources.get(position).getStatus().equalsIgnoreCase("Verified")) {
            tv_status.setBackgroundColor(Color.parseColor("#388E3C"));
        } else if (mResources.get(position).getStatus().equalsIgnoreCase("confirmation pending")) {
            tv_status.setBackgroundColor(Color.parseColor("#FFC107"));
        } else if (mResources.get(position).getStatus().equalsIgnoreCase("Confirm")) {
            tv_status.setBackgroundColor(Color.parseColor("#F57F17"));
        }else if (mResources.get(position).getStatus().equalsIgnoreCase("Completed")) {
            tv_status.setBackgroundColor(Color.parseColor("#388E3C"));
        }
        container.addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        Log.d(TAG, "destroyItem() called with: " + "container = [" + container + "], position = [" + position
                + "], object = [" + object + "]");
        container.removeView((LinearLayout) object);
    }
}
