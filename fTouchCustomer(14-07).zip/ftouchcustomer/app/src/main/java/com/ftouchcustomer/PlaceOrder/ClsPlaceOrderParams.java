package com.ftouchcustomer.PlaceOrder;

public class ClsPlaceOrderParams {

    int CustomerID = 0;
    int MerchantID = 0;
    String MobileNo = "";
    String MerchantCode = "";
    String DeliveryType = "";
    int Items = 0;
    int AddressID = 0;
    String Comment = "";

}
