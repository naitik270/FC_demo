package com.ftouchcustomer.Classes;

public class ClsTotalAmountCustomerCodeWise {

    Double TotalAmount;
    String CustomerCode;

    public Double getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        TotalAmount = totalAmount;
    }

    public String getCustomerCode() {
        return CustomerCode;
    }

    public void setCustomerCode(String customerCode) {
        CustomerCode = customerCode;
    }
}
