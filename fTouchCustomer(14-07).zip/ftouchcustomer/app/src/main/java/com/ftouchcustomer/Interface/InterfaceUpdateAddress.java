package com.ftouchcustomer.Interface;

import com.ftouchcustomer.CustomerAddress.postAddress.ClsCustomerAddress;
import com.ftouchcustomer.CustomerAddress.updateAddress.ClsUpdateAddress;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface InterfaceUpdateAddress {

    @POST("CustomerV1/UpdateCustomerAddress")
    Call<ClsCustomerAddress> UpdateAddress(@Body ClsCustomerAddress clsCustomerAddress);

}
