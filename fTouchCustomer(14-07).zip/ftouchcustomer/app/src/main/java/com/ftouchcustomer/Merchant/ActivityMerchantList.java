package com.ftouchcustomer.Merchant;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ftouchcustomer.Appointment.AppointmentList.ActivityAppointmentMerchantList;
import com.ftouchcustomer.Appointment.NewAppointment.ActivityNewAppointment;
import com.ftouchcustomer.Global.ClsGlobal;
import com.ftouchcustomer.Global.ClsUserInfo;
import com.ftouchcustomer.NavigationTabs.BottomNavigationActivity;
import com.ftouchcustomer.Orders.ActivityOrderItemList;
import com.ftouchcustomer.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import static com.ftouchcustomer.Global.ConnectionCheckBroadcast.CheckInternetConnection;

public class ActivityMerchantList extends AppCompatActivity {

    private static final int PICK_GPS = 7;
    final private int REQUEST_CODE_ASK_PERMISSIONS = 123;
    RecyclerView recyclerView;
    TextView tv_no_item_found;
    private MerchantViewModel merchantViewModel;
    private FusedLocationProviderClient fusedLocationProviderClient;
    ProgressBar progress_bar;
    ClsUserInfo clsUserInfo;

    String merchantName = null;
    String city = null;
    String pinCode = null;
    String category = null;
    String State = null;
    String address = null;
    String mobileNumber = null;
    private String productName = null;

    private ProgressDialog pd;
    private List<ClsMerchantResponseList> responseList = new ArrayList<>();
    private AdapterMerchantList adapter;

    private double lat;
    private double lang;
    private Location currentLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant);

        clsUserInfo = ClsGlobal.getUserInfo(this);

        merchantName = getIntent().getStringExtra("merchantName");
        city = getIntent().getStringExtra("city");
        pinCode = getIntent().getStringExtra("pinCode");
        category = getIntent().getStringExtra("category");

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        merchantViewModel = new ViewModelProvider(this).get(MerchantViewModel.class);

        FloatingActionButton fab = findViewById(R.id.fab_add);
        recyclerView = findViewById(R.id.recyclerView);
        tv_no_item_found = findViewById(R.id.tv_no_item_found);
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        progress_bar = findViewById(R.id.progress_bar);
        adapter = new AdapterMerchantList(this, "FragmentMerchant");
        recyclerView.setAdapter(adapter);

        requestPermission();


        fab.setOnClickListener(view -> {

            if (responseList.size() != 0) {

                Intent intent = new Intent(this, ActivityFilterMerchantList.class);
                startActivityForResult(intent, REQUEST_CODE);
            } else {
                Toast.makeText(this, "NO ITEMS FOUND.", Toast.LENGTH_SHORT).show();
            }

        });

        adapter.setOnMobileClick(clsMerchantResponseList -> {
            if (clsMerchantResponseList.getMobileNo() != null) {

                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + clsMerchantResponseList.getMobileNo()));
                startActivity(callIntent);
            } else {
//                Toast.makeText(this, "no contact details found", Toast.LENGTH_SHORT).show();
                dialog(clsMerchantResponseList.getCustomerCode(),
                        "Mobile Number", "Asking For Mobile Number");
            }
        });

        adapter.setOnTimeClick((lst, clsMerchantResponseList) -> {
            if (lst != null && lst.size() != 0) {
                displayTiming(lst);
            } else {
//                Toast.makeText(this, "No timing detail found", Toast.LENGTH_SHORT).show();
                dialog(clsMerchantResponseList.getCustomerCode()
                        , "Timing", "Asking For Timing");
            }
        });

        adapter.setOnShopNowClick(lst -> {
            if (lst.getMenuUrl() != null && !lst.getMenuUrl().equalsIgnoreCase("Not found")) {
                shopNow(lst);
            } else {
                Toast.makeText(this, "No Online items found", Toast.LENGTH_SHORT).show();
            }
        });


        adapter.setOnWtsAppClick(clsMerchantResponseList -> {
            if (clsMerchantResponseList.getMobileNo() != null) {
                ClsGlobal.SentMessageToWhatApp(this,
                        "+91 " + clsMerchantResponseList.getMobileNo(),
                        "Hiii", "WhatsApp");
            } else {
//                Toast.makeText(this, "Not Found WhatsApp Number", Toast.LENGTH_SHORT).show();
                dialog(clsMerchantResponseList.getCustomerCode(),
                        "WhatsApp Number", "Asking For WhatsApp Number");
            }
        });

        adapter.setOnMainImageClick(clsMerchantResponseList -> {
            if (clsMerchantResponseList.getLogoUrl().contains("Not found")) {
                dialog(clsMerchantResponseList.getCustomerCode()
                        , "Logo", "Asking For Logo");
            }
        });

        adapter.setOnCastLayoutClick(clsMerchantResponseList -> {
            Log.d("--adapter--", "category: " + clsMerchantResponseList.getCategories());
            if (clsMerchantResponseList.getCategories() != null &&
                    !clsMerchantResponseList.getCategories().equalsIgnoreCase("")) {
            } else {
                dialog(clsMerchantResponseList.getCustomerCode(),
                        "Category", "Asking For Category");
            }
        });

        adapter.setOnMapClick(clsMerchantResponseList -> {
            if (clsMerchantResponseList.getAddress() != null) {
                showAddressDialog(clsMerchantResponseList);
            } else {
                Toast.makeText(this, "No address found.", Toast.LENGTH_SHORT).show();
            }
        });

        recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(
                linearLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount) {
                progress_bar.setVisibility(View.VISIBLE);

                if (CheckInternetConnection(ActivityMerchantList.this)) {
                    Log.d("getMerchantList", "onLoadMore: ");
                    getMerchantList(++page);
                } else {
                    progress_bar.setVisibility(View.GONE);
                    Toast.makeText(ActivityMerchantList.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void shopNow(ClsMerchantResponseList clsMerchantResponseList) {

        Intent intent = new Intent(this, ActivityOrderItemList.class);
        intent.putExtra("clsMerchantResponseList", clsMerchantResponseList);
        startActivity(intent);
    }

    void displayTiming(List<ClsTiming> lstClsTimings) {

        Dialog dialog = new Dialog(Objects.requireNonNull(this));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_listview);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(Objects.requireNonNull(dialog.getWindow()).getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        dialog.getWindow().setAttributes(lp);

        ListView lv_lst = dialog.findViewById(R.id.lv_lst);
        AdapterTimeList adapterTimeList =
                new AdapterTimeList(this, lstClsTimings);
        lv_lst.setAdapter(adapterTimeList);
        dialog.show();
    }


    @Override
    public void onResume() {
        super.onResume();
        Log.d("FragmentMerchant", "onResume: ");
    }

    private void getMerchantList(int currentPageNo) {


        ClsMerchantParams obj = new ClsMerchantParams();

        obj.setCurrentIndex(currentPageNo);
        obj.setLatitude(lat);
        obj.setLongitude(lang);

        if (merchantName != null && merchantName.isEmpty()) {
            merchantName = null;
        }
        obj.setCompanyName(merchantName);


        if (productName != null && productName.isEmpty()) {
            productName = null;
        }
        obj.setProductName(productName);
        if (pinCode != null && pinCode.isEmpty()) {
            pinCode = null;
        }
        obj.setPinCode(pinCode);
        if (city != null && city.isEmpty()) {
            city = null;
        }
        obj.setCity(city);
        if (address != null && address.isEmpty()) {
            address = null;
        }
        obj.setAddress(address);

        if (mobileNumber != null && mobileNumber.isEmpty()) {
            mobileNumber = null;
        }
        obj.setMobileNo(mobileNumber);

        if (State != null && State.isEmpty()) {
            State = null;
        }
        obj.setState(State);
        if (category != null && category.isEmpty()) {
            category = null;
        }
        obj.setCategory(category);

        Gson gson = new Gson();
        String jsonInString = gson.toJson(obj);
        Log.e("--result--", "Appoint: " + jsonInString);

        merchantViewModel.getMerchantList(obj)
                .observe(this, clsMerchantResponse -> {
                    pd.dismiss();
                    String msg = clsMerchantResponse.getSuccess();
                    int _totalPages = clsMerchantResponse.getTotalPages();
                    Log.e("--result--", "msg: " + msg);
                    Log.e("--result--", "_totalPages: " + _totalPages);
                    if ("0".equals(msg)) {
                        progress_bar.setVisibility(View.GONE);
                    } else if ("1".equals(msg)) {
                        if (clsMerchantResponse.getData().size() > 0){
                            responseList.addAll(clsMerchantResponse.getData());
                        }

                        if (responseList.size() != 0) {
                            adapter.addList(responseList);
                            progress_bar.setVisibility(View.GONE);
                        }
                    }
                });
    }

    private void dialog(String merchantCode, String askingFor, String label) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(label);

        LayoutInflater inflater = this.getLayoutInflater();
        View viewInflated = inflater.inflate(R.layout.dialog_edittext, null);

        final EditText input = (EditText) viewInflated.findViewById(R.id.input);
        builder.setView(viewInflated);

        builder.setPositiveButton("Save", (dialog, which) ->
                getMerchantProfileAdd(merchantCode, askingFor, input.getText().toString()));
        builder.setNegativeButton("Cancel", (dialog, which) ->
                dialog.cancel());

        builder.show();
    }

    private void getMerchantProfileAdd(String merchantCode, String askingFor, String comment) {

        ClsMerchantProfileAdd obj = new ClsMerchantProfileAdd();
        obj.setMerchantCode(merchantCode);
        obj.setCustomerId(clsUserInfo.getCustomerId());
        obj.setCustomerMobileNo(clsUserInfo.getRegisteredmobilenumber());
        obj.setName(clsUserInfo.getName());
        obj.setAskingFor(askingFor);
        obj.setComment(comment);

        Gson gson = new Gson();
        String jsonInString = gson.toJson(obj);
        Log.e("--URL--", "clsMerchantProfileAdd---" + jsonInString);

        merchantViewModel.getMerchantProfileAdd(obj)
                .observe(this, clsMerchantProfileAdd -> {

                    if (clsMerchantProfileAdd.getSuccess().equalsIgnoreCase("1")) {
                        Toast.makeText(this, "Requested Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, clsMerchantProfileAdd.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void requestPermission() {

        String[] PERMISSIONS = {
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION,
        };

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, PERMISSIONS, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            fetchLastLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_CODE_ASK_PERMISSIONS) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                fetchLastLocation();
            } else {
                Toast.makeText(this, "Please allow permission to get Service Provider near by you.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, BottomNavigationActivity.class);
                startActivity(intent);
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void fetchLastLocation() {

        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            try {
                gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            } catch (Exception ex) {
                Toast.makeText(this, ex.toString(), Toast.LENGTH_SHORT).show();
            }
            try {
                network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            } catch (Exception ex) {
                Toast.makeText(this, ex.toString(), Toast.LENGTH_SHORT).show();
            }

            if (!gps_enabled && !network_enabled) {
                showGPSDisabledAlertToUser();
            } else {
                Task<Location> task = fusedLocationProviderClient.getLastLocation();
                task.addOnSuccessListener(location -> {
                    if (location != null) {
                        currentLocation = location;

                        lat = currentLocation.getLatitude();
                        lang = currentLocation.getLongitude();
                        Log.d("--abc--", "fetchLastLocation: " + lat + "-" + lang);

                        pd = ClsGlobal._prProgressDialog(this, "Getting list...", false);
                        pd.show();
                        if (CheckInternetConnection(this)) {
                            getMerchantList(1);
                        } else {
                            pd.dismiss();
                            Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        } else {
            Toast.makeText(this, "No Location recorded", Toast.LENGTH_SHORT).show();
        }
    }

    private void showGPSDisabledAlertToUser() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("GPS is disabled in your device. Would you like to enable it?")
                .setCancelable(false)
                .setPositiveButton("Goto Settings Page To Enable GPS",
                        (dialog, id) -> {
                            Intent callGPSSettingIntent = new Intent(
                                    android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivityForResult(callGPSSettingIntent, PICK_GPS);
                        });
        alertDialogBuilder.setNegativeButton("Cancel",
                (dialog, id) -> dialog.cancel());
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

    public static final int REQUEST_CODE = 1;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        try {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == PICK_GPS) {
                LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                boolean isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);

                if (!isGpsEnabled) {
                    Intent intent = new Intent(this, BottomNavigationActivity.class);
                    startActivity(intent);
                    Toast.makeText(this, "Please on GPS to get Service Provider near by you.", Toast.LENGTH_SHORT).show();
                } else {
                    fetchLastLocation();
                }
            }

            if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
                merchantName = data.getStringExtra("requiredMerchantName");
                city = data.getStringExtra("requiredCity");
                pinCode = data.getStringExtra("requiredPinCode");
                category = data.getStringExtra("requiredCategory");
                address = data.getStringExtra("requiredAddress");

                responseList.clear();
                getMerchantList(1);
            }
        } catch (Exception ex) {
            Toast.makeText(ActivityMerchantList.this, ex.toString(),
                    Toast.LENGTH_SHORT).show();
        }

    }

    @SuppressLint("SetTextI18n")
    private void showAddressDialog(ClsMerchantResponseList clsMerchantResponseList) {
        final Dialog dialog = new Dialog(ActivityMerchantList.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_warning);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(Objects.requireNonNull(dialog.getWindow()).getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        TextView content = dialog.findViewById(R.id.content);
        content.setText(clsMerchantResponseList.getAddress());

        dialog.findViewById(R.id.bt_close).setOnClickListener(v -> {
            dialog.dismiss();
            Double _latitude = Double.valueOf(clsMerchantResponseList.getLatitude());
            Double _longitude = Double.valueOf(clsMerchantResponseList.getLongitude());

            String uri = String.format(Locale.ENGLISH,
                    "http://maps.google.com/maps?q=loc:%f,%f", _latitude, _longitude);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            startActivity(intent);
        });
        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
}