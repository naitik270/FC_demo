package com.ftouchcustomer.Complain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.ftouchcustomer.R;

public class CropImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_image);

        Intent intent = getIntent();
        String image_path= intent.getStringExtra("imageUri");
        Uri imageUri = Uri.parse(image_path);


    }
}
