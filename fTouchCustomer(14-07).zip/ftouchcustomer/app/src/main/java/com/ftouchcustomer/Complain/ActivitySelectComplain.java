package com.ftouchcustomer.Complain;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import com.ftouchcustomer.Global.ApiClient;
import com.ftouchcustomer.Global.ClsGlobal;
import com.ftouchcustomer.Global.ClsUserInfo;
import com.ftouchcustomer.Global.ConnectionDetector;
import com.ftouchcustomer.Interface.InterfaceCustomerComplain;
import com.ftouchcustomer.R;
import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ActivitySelectComplain extends AppCompatActivity {

    String _complainName = "";

    List<ClsComplainList> lstClsComplainLists = new ArrayList<>();
    List<String> lstStringWithTags = new ArrayList<String>();

    //    Button btn_send_complain;
    Bitmap bmp;
    String imagePath = "";
    String extension = "";
    String filename = "";
    String file = "";
    File finalFile = new File("");
    Boolean _Selected = false;
    ImageView iv_doc_file;

    String mobile = "";
    String _code = "";
    EditText edt_remark;
    Toolbar toolbar;
    ConnectionDetector cd;
    Boolean isInternetPresent = false;
    ImageView iv_add_img;
    ImageView img_clear;
    ImageView iv_expand_more;
    TextView txt_complain;
    RelativeLayout relative_layout_save;
    EditText et_name;
    EditText et_mobile;
    ClsUserInfo clsUserInfo;

    public static final int REQUEST_CODE_FOR_COMPLAIN = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_complain);

        toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        main();
    }

    private void main() {

        clsUserInfo = ClsGlobal.getUserInfo(this);

        Intent intent = getIntent();
        mobile = intent.getStringExtra("mobile");
        _code = intent.getStringExtra("_code");

        Log.d("--GSON--", "_code: " + _code);

        edt_remark = findViewById(R.id.edt_remark);
        relative_layout_save = findViewById(R.id.relative_layout_save);
        txt_complain = findViewById(R.id.txt_complain);
        iv_add_img = findViewById(R.id.iv_add_img);
        iv_doc_file = findViewById(R.id.iv_doc_file);
        iv_expand_more = findViewById(R.id.iv_expand_more);

        et_name = findViewById(R.id.et_name);
        et_mobile = findViewById(R.id.et_mobile);

        et_mobile.setText(clsUserInfo.getRegisteredmobilenumber());
        et_name.setText(clsUserInfo.getName());

        iv_expand_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ActivityDisplayComplainList.class);
                startActivityForResult(intent, REQUEST_CODE_FOR_COMPLAIN);
            }
        });

        iv_add_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                browseImage();
            }
        });

        relative_layout_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean val = validation();
                if (val) {
                    cd = new ConnectionDetector(getApplicationContext());
                    isInternetPresent = cd.isConnectingToInternet();

                    if (isInternetPresent) {
                        // Final code...
                        uploadComplainError();

                    } else {
                        Toast.makeText(getApplicationContext(),
                                "No Internet Connection", Toast.LENGTH_SHORT)
                                .show();
                    }
                }




                uploadComplainError();

            }
        });
    }


    private Boolean validation() {

        if (et_name.getText() == null || et_name.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Enter Name.", Toast.LENGTH_SHORT).show();
            et_name.requestFocus();
            return false;
        }
        if (et_mobile.getText() == null || et_mobile.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Enter Mobile.", Toast.LENGTH_SHORT).show();
            et_mobile.requestFocus();
            return false;
        }

        if (txt_complain.getText() == null || txt_complain.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Select complain type.", Toast.LENGTH_SHORT).show();
            txt_complain.requestFocus();
            return false;
        }

        if (edt_remark.getText() == null || edt_remark.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), "Enter remark.", Toast.LENGTH_SHORT).show();
            edt_remark.requestFocus();
            return false;
        }
        return true;
    }

    private static final int PICK_FROM_FILE = 2;
    String complain_name = "";

    public void browseImage() {
        Intent intent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        intent.setType("image/*");
        intent.putExtra("return-data", false);
        startActivityForResult(
                Intent.createChooser(intent, "Complete action using"),
                PICK_FROM_FILE);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d("--Code--", "1st");

        if (requestCode == PICK_FROM_FILE && resultCode == RESULT_OK && data != null) {
            Uri _SelectedFileUri = data.getData();
            try {
                bmp = MediaStore.Images.Media.getBitmap(this.getContentResolver(), _SelectedFileUri);
                finalFile = new File(ClsGlobal.getRealPathFromURI(ActivitySelectComplain.this,_SelectedFileUri));
                imagePath = GetFilePathFromDevice.getPath(ActivitySelectComplain.this, data.getData());
                filename = imagePath.substring(imagePath.lastIndexOf("/") + 1);

                if (filename.indexOf(".") > 0) {
                    file = filename.substring(0, filename.lastIndexOf("."));
                } else {
                    file = filename;
                }
                if (filename.lastIndexOf(".") > 0) {
                    extension = filename.substring(filename.lastIndexOf("."));
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            iv_doc_file.setImageBitmap(bmp);
            _Selected = true;
            Log.d("--Code--", "1st");

        } else if (requestCode == 3 && resultCode == Activity.RESULT_OK) {
            Toast.makeText(this, "Event Call", Toast.LENGTH_SHORT).show();

            Log.d("--Code--", "2nd");

        } else if (requestCode == REQUEST_CODE_FOR_COMPLAIN && resultCode == Activity.RESULT_OK) {

            Log.d("--Code--", "3rd");


            complain_name = data.getStringExtra("complain_name");
            txt_complain.setText(complain_name);
        }
    }

    public void onLoadImageClick(View view) {
        startActivityForResult(getPickImageChooserIntent(), 200);
    }

    public Intent getPickImageChooserIntent() {

        // Determine Uri of camera image to save.
        Uri outputFileUri = getCaptureImageOutputUri();

        List<Intent> allIntents = new ArrayList<>();
        PackageManager packageManager = getPackageManager();

        // collect all camera intents
        Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        List<ResolveInfo> listCam = packageManager.queryIntentActivities(captureIntent, 0);
        for (ResolveInfo res : listCam) {
            Intent intent = new Intent(captureIntent);
            intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
            intent.setPackage(res.activityInfo.packageName);
            if (outputFileUri != null) {
                intent.putExtra(MediaStore.EXTRA_OUTPUT, outputFileUri);
            }
            allIntents.add(intent);
        }

        // collect all gallery intents
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        List<ResolveInfo> listGallery = packageManager.queryIntentActivities(galleryIntent, 0);
        for (ResolveInfo res : listGallery) {
            Intent intent = new Intent(galleryIntent);
            intent.setComponent(new ComponentName(res.activityInfo.packageName, res.activityInfo.name));
            intent.setPackage(res.activityInfo.packageName);
            allIntents.add(intent);
        }

        // the main intent is the last in the list (fucking android) so pickup the useless one
        Intent mainIntent = allIntents.get(allIntents.size() - 1);
        for (Intent intent : allIntents) {
            if (intent.getComponent().getClassName().equals("com.android.documentsui.DocumentsActivity")) {
                mainIntent = intent;
                break;
            }
        }
        allIntents.remove(mainIntent);

        // Create a chooser from the main intent
        Intent chooserIntent = Intent.createChooser(mainIntent, "Select source");

        // Add all other intents
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, allIntents.toArray(new Parcelable[allIntents.size()]));
        // bitmapUri=outputFileUri;
        return chooserIntent;
    }

    private Uri getCaptureImageOutputUri() {
        Uri outputFileUri = null;
        File getImage = getExternalCacheDir();
        if (getImage != null) {
            outputFileUri = Uri.fromFile(new File(getImage.getPath(), "pickImageResult.jpeg"));
        }
        // bitmapUri=outputFileUri;
        return outputFileUri;
    }

    void uploadComplainError() {

        String _jpgFromFile = filename;
        _jpgFromFile = _jpgFromFile.replace(".jpg", "");

        String remark = edt_remark.getText().toString().concat("-->")
                .concat(" ").concat("Name : ").concat(clsUserInfo.getName());

        ClsCustomerComplainParams obj = new ClsCustomerComplainParams();
        obj.setMobileNumber(clsUserInfo.getRegisteredmobilenumber());
        obj.setCustomerCode("");
        obj.setRequestSubject(txt_complain.getText().toString());
        obj.setRequestRemark(remark);
        obj.setProductName(ClsGlobal.AppName);
        obj.setFileName(_jpgFromFile);
        obj.setFileExtension(extension);
        obj.setData(ClsGlobal.getBytes(finalFile));
        obj.setApplicationType(ClsGlobal.ApplicationType);

        Gson gson = new Gson();
        String jsonInString = gson.toJson(obj);
        Log.d("--GSON--", "uploadDocumentAPI- " + jsonInString);

        InterfaceCustomerComplain interfaceComplain =
                ApiClient.getRetrofitInstance().create(InterfaceCustomerComplain.class);

        Call<ClsCustomerComplainParams> call
                = interfaceComplain.postComplain(obj);

        final ProgressDialog pd = ClsGlobal._prProgressDialog(ActivitySelectComplain.this,
                "Working...", true);
        pd.show();

        call.enqueue(new Callback<ClsCustomerComplainParams>() {
            @Override
            public void onResponse(Call<ClsCustomerComplainParams> call,
                                   Response<ClsCustomerComplainParams> response) {

                pd.dismiss();
                if (response.body() != null) {
                    String _response = response.body().getSuccess();
                    switch (_response) {
                        case "1":
                            Toast.makeText(ActivitySelectComplain.this,
                                    "Complain send successfully", Toast.LENGTH_SHORT).show();
                            finish();
                            break;
                        case "2":
                            Toast.makeText(ActivitySelectComplain.this,
                                    "Complain not send", Toast.LENGTH_SHORT).show();
                            break;
                        default:
                            Toast.makeText(ActivitySelectComplain.this,
                                    "No response", Toast.LENGTH_SHORT).show();
                            break;
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Server error...!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ClsCustomerComplainParams> call, Throwable t) {
                pd.dismiss();
                Toast.makeText(getApplicationContext(),
                        "Something went wrong...Please try later!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
