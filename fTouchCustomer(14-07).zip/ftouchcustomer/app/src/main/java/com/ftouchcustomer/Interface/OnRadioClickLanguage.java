package com.ftouchcustomer.Interface;


import com.ftouchcustomer.Language.ClsLanguageGetSet;

public interface OnRadioClickLanguage {
    void OnItemClick(ClsLanguageGetSet clsSettingNameVal,int position);
}
