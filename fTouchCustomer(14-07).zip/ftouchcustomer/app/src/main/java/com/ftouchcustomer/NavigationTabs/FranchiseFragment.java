package com.ftouchcustomer.NavigationTabs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ftouchcustomer.R;
;

public class FranchiseFragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_home, container, false);


     /*   setHasOptionsMenu(true);

        Toolbar toolbar = v.findViewById(R.id.toolbar);
        //for crate home button
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        Objects.requireNonNull(activity).setSupportActionBar(toolbar);
        toolbar.setTitle("Lead");
        toolbar.setTitleTextColor(Color.parseColor("#FFFFFF"));
*/
        main(v);

        return v;
    }

    private void main(View v) {
    }


}
