package com.ftouchcustomer.Interface;

import com.ftouchcustomer.Complain.ClsCustomerComplainParams;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface InterfaceCustomerComplain {

    @POST("ComplainDisposition/RegisterCustomerComplain")
    Call<ClsCustomerComplainParams> postComplain(@Body ClsCustomerComplainParams obj);

}
